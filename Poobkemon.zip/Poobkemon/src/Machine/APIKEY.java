package Machine;

public class APIKEY {
    private static final String API_KEY = "AIzaSyB6fCKcNDvBEO3q9RkUiqnNLWeuBjuM_-Y";
    private static final String ID = "poobkemon-458614";
    private static final String NUM = "484195844611";


    public static String getApiKey() {
        return API_KEY;
    }

    public static String getId() {
        return ID;
    }

    public static String getNum() {
        return NUM;
    }

    


}
