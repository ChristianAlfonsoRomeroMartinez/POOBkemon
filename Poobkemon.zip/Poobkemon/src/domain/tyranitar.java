package domain;

public class tyranitar extends Pokemon {

    public tyranitar() {
        super("Tyranitar", 7, 404, 243, 317, 403, 328, 350, "Roca",85);
    }
}
