package domain;

public class donphan extends Pokemon {

    public donphan() {
        super("Donphan", 11, 384, 218, 240, 372, 240, 372, "Tierra",95);
    }
}
