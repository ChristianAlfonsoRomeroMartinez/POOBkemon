package domain;

public class raichu extends Pokemon {

    public raichu() {
        super("Raichu", 14, 324, 350, 306, 306, 284, 229, "Electrico",110);
    }
}
