package domain;

public class charizard extends Pokemon {

    public charizard() {
        super("Charizard", 6, 360, 328, 348, 293, 295, 280, "Fuego", 105);
    }
}
