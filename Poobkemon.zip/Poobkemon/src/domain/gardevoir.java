package domain;

public class gardevoir extends Pokemon {


    public gardevoir() {
        super("Gardevoir", 8, 340, 284, 383, 251, 361, 251, "Psíquico",105);
    }


}
