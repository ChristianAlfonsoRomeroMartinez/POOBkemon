package domain;

public class metagross extends Pokemon {

    public metagross() {
        super("Metagross", 10, 364, 262, 317, 405, 306, 394, "Acero",90);
    }
}
