package domain;

public class machamp extends Pokemon {

    public machamp() {
        super("Machamp", 12, 384, 229, 251, 394, 295, 284, "Lucha",100);
    }
}
