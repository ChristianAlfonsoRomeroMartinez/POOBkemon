package domain;

public class blastoise extends Pokemon {

    public blastoise() {
        super("Blastoise", 2, 362, 280, 295, 291, 339, 328, "Agua",95);
    }
}
