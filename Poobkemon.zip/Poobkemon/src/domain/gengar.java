package domain;

public class gengar extends Pokemon {

    public gengar() {
        super("Gengar", 4, 324, 350, 394, 251, 273, 240, "Fantasma",115);
    }
}
