package domain;

public class snorlax extends Pokemon {

    public snorlax() {
        super("Snorlax", 9, 524, 174, 251, 350, 350, 251, "Normal",80);
    }
}
