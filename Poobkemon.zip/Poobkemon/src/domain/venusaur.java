package domain;

public class venusaur extends Pokemon {

    public venusaur() {
        super("Venusaur", 3, 364, 284, 394, 251, 273, 240, "Planta",90);
    }
}
