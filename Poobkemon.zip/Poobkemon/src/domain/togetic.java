package domain;

public class togetic extends Pokemon {

    public togetic() {
        super("Togetic", 6, 314, 196, 284, 196, 339, 295, "Hada",110);
    }
}
