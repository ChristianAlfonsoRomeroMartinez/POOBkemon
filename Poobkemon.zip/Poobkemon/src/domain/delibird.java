package domain;

public class delibird extends Pokemon {

    public delibird() {
        super("Delibird", 13, 294, 273, 251, 229, 207, 207, "Hielo", 120);
    }
    
}
