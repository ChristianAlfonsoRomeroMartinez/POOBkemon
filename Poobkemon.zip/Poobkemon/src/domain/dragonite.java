package domain;

public class dragonite extends Pokemon {

    public dragonite() {
        super("Dragonite", 5, 386, 284, 328, 403, 328, 317, "Dragon",100);
    }
}
